declare module "autoprefixer-stylus" {
  const t: any;
  export = t;
}
declare module "rollup-plugin-typescript" {
  const t: any;
  export = t;
}

declare module "rollup-plugin-babel" {
  const t: any;
  export = t;
}

declare module "rollup-plugin-serve" {
  const t: any;
  export = t;
}
declare module "rollup-plugin-livereload" {
  const t: any;
  export = t;
}
